# 注入数据 JSON 结构（data_schema）

`scripts/process_crossplatform.py` 读取的 JSON 约定如下。

## 顶层

```json
{
  "meta": { ... },
  "videos": [ ... ]
}
```

## meta 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| platform | string | 平台名（如「B站(哔哩哔哩)」） |
| source | string | 采集来源（如「八爪鱼云采集 templateId=2886 (B站关键词搜索视频采集)」） |
| crawled_at | string | 采集时间（如「2026-08-31 16:55」） |
| keywords | string[] | 搜索关键词列表（如 ["鳜鱼价格","鲈鱼价格"]） |
| raw_rows | int | 原始结果条数（如 80） |
| selected_rows | int | 筛选后条数（如 16） |
| filter | string | 筛选规则说明（保留/剔除标准） |

## videos[] 字段

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| platform | string | ✅ | 平台 |
| keyword | string | ✅ | 命中的搜索关键词；含「鳜」→ 标记为鳜鱼，否则 → 鲈鱼（脚本据此上色，可按需改） |
| title | string | ✅ | 视频标题 |
| author | string | ✅ | UP主/作者 |
| play | int | ✅ | 播放数 |
| like | int | ✅ | 点赞数 |
| comment | int | ✅ | 评论数 |
| fav | int | ⬜ | 收藏数（可选） |
| date | string | ✅ | 发布时间（如「2026-08-10」） |
| bvid | string | ⬜ | B站 BV 号（可选，用于溯源） |
| url | string | ✅ | 视频链接 |
| tags | string | ⬜ | 标签（可选） |

## 示例

```json
{
  "meta": {
    "platform": "B站(哔哩哔哩)",
    "source": "八爪鱼云采集 templateId=2886 (B站关键词搜索视频采集)",
    "crawled_at": "2026-08-31 16:55",
    "keywords": ["鳜鱼价格", "鲈鱼价格"],
    "raw_rows": 80,
    "selected_rows": 16,
    "filter": "保留价格行情语义且为水产相关的视频，剔除路亚装备/做菜/魔方/手机等无关"
  },
  "videos": [
    {"platform":"B站","keyword":"鳜鱼价格",
     "title":"石斑最低15一斤，鳜鱼反涨到45，广州沙园（2026.08上旬）",
     "author":"市场博物","play":15384,"like":526,"comment":137,"fav":98,
     "date":"2026-08-10","bvid":"BV1xnuo6tEL8",
     "url":"https://www.bilibili.com/video/BV1xnuo6tEL8",
     "tags":"海鲜,海鲜价格,海鱼,广州美食,石斑鱼"}
  ]
}
```

## 渲染行为

- 表格按 `keyword` 含「鳜」判定品种彩色 tag（可改脚本扩展）。
- 标题含具体报价（正则 `(\d+(\.\d+)?\s*(元|块)|元/斤|/斤|\d+\s*块|\d+\s*元)`）的行
  自动高亮背景 `#fff7ed`，并抽入"价格信号" callout。
