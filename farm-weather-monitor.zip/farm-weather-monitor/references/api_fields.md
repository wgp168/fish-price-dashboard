# 两源字段对照与 WMO code 表

## Open-Meteo（主源）

端点：`https://api.open-meteo.com/v1/forecast`

关键参数：
```
latitude, longitude
current  = temperature_2m,wind_speed_10m,wind_direction_10m,relative_humidity_2m,
           precipitation,surface_pressure,weather_code
hourly   = shortwave_radiation
daily    = weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,
           precipitation_probability_max,wind_speed_10m_max,
           wind_direction_10m_dominant,shortwave_radiation_sum
forecast_days = 7
timezone = Asia/Shanghai
wind_speed_unit = kmh          # 默认 km/h，显式声明防止单位歧义
```

**免费、无需 Key、CC BY 4.0、WMO 标准、15 分钟更新。**

注意：太阳辐射只在 `hourly` 提供，**没有 current 项**。
需按 `current.time` 在 `hourly.time` 里找最近时刻取值（脚本已实现）。

| 用户要的指标 | Open-Meteo 字段 | 单位 |
|---|---|---|
| 气温 | `current.temperature_2m` | ℃ |
| 风速 | `current.wind_speed_10m` | km/h |
| 风向 | `current.wind_direction_10m` | 度（需转 16 方位）|
| 太阳辐射 | `hourly.shortwave_radiation`（就近取）| W/m² |
| 降水量 | `current.precipitation` | mm |
| 相对湿度 | `current.relative_humidity_2m` | % |
| 气压 | `current.surface_pressure` | hPa |
| 天气 | `current.weather_code` | WMO code（需转中文）|

`daily` 里 `shortwave_radiation_sum` 单位是 **MJ/m²**（不是 W/m²），渲染时别标错。

## 高德天气（校验源）

MCP：`mcp__amap-maps__maps_weather(city="320282")`
REST：`https://restapi.amap.com/v3/weather/weatherInfo?city=<adcode>&key=<Web服务Key>`

返回 `forecasts[]`，每元素：

| 字段 | 含义 |
|---|---|
| `date` | 日期 |
| `dayweather` / `nightweather` | 白天/夜间天气中文 |
| `daytemp_float` / `nighttemp_float` | 白天/夜间气温（浮点）|
| `daytemp` / `nighttemp` | 同上（整数字符串）|
| `daywind` / `nightwind` | 风向中文（如"东北"）|
| `daypower` / `nightpower` | 风力等级（如"1-3"）|

**只给 4 天**。且**不提供**太阳辐射 / 降水量 mm / 相对湿度 / 气压 → 无法替代 Open-Meteo。

## WMO weather_code → 中文

在 `weather_fetcher.py` 的 `wmo_to_text()` 里维护。告警阈值：**code ≥ 95 视为雷暴，HIGH**。

| code | 图标 | 中文 | code | 图标 | 中文 |
|---|---|---|---|---|---|
| 0 | ☀️ | 晴 | 65 | 🌧️ | 大雨 |
| 1 | 🌤️ | 局部多云 | 66/67 | 🌧️ | 冻雨 |
| 2 | ⛅ | 多云 | 71/73/75 | 🌨️ | 小/中/大雪 |
| 3 | ☁️ | 阴 | 77 | 🌨️ | 米雪 |
| 45/48 | 🌫️ | 雾/雾凇 | 80/81 | 🌦️/🌧️ | 阵雨(弱/中) |
| 51/53/55 | 🌦️ | 毛毛雨(弱/中/强) | 82 | ⛈️ | 阵雨(强) |
| 56/57 | 🌧️ | 冻毛毛雨 | 85/86 | 🌨️ | 阵雪/强阵雪 |
| 61/63 | 🌧️ | 小/中雨 | 95 | ⛈️ | **雷暴** |
| | | | 96 | ⛈️ | 雷暴+冰雹 |
| | | | 99 | ⛈️ | 强雷暴+冰雹 |

## 角度 → 16 方位

`deg_to_compass()`：`idx = int((deg % 360 + 11.25) // 22.5) % 16`

```
北 / 北东北 / 东北 / 东北东 / 东 / 东南东 / 东南 / 南东南
南 / 南西南 / 西南 / 西南西 / 西 / 西北西 / 西北 / 北西北
```

## 高德 MCP 错误码

| 错误 | 含义 | 处理 |
|---|---|---|
| `USERKEY_PLAT_NOMATCH` | Key 申请的接口类型与实际请求不匹配 | **用户侧重新提交/授权 Key**，代码层无法绕 |
| `INVALID_USER_KEY` | Key 错误或未生效 | 确认 Key 已提交并过生效期 |
| `DAILY_QUERY_OVER_LIMIT` | 日配额超 | 次日再试，或降级单源 |
