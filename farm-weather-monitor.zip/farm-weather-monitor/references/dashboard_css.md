# 看板所需 CSS 片段

注入气象区块前，把下面整段粘进看板 `<style>...</style>` 内（建议放在 `footer{}` 规则之前）。

依赖的 CSS 变量（看板主题通常已有，缺失则需补）：
`--line`（边框）、`--card`（卡片底色）、`--ink`（主文字）、`--sub`（次要文字）、
`--brand`（链接色）、`--shadow`（阴影）、`--shadow-lg`（大阴影）。

```css
  .location-card{border-left:4px solid #0ea5e9}
  .mini-map-link{display:block;position:relative;border-radius:12px;overflow:hidden;margin-top:14px;cursor:pointer;transition:transform .15s,box-shadow .15s;border:1px solid var(--line)}
  .mini-map-link:hover{transform:translateY(-2px);box-shadow:var(--shadow-lg)}
  .mini-map{display:block;width:100%;height:280px;background:#e8f1e0}
  .map-overlay{position:absolute;top:12px;right:12px;background:rgba(14,165,233,.92);color:#fff;font-weight:700;font-size:12px;padding:6px 12px;border-radius:8px;backdrop-filter:blur(6px);box-shadow:0 4px 12px rgba(14,165,233,.35)}
  .nav-actions{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:14px}
  .nav-btn{display:inline-block;font-size:13px;font-weight:600;padding:8px 14px;border-radius:8px;border:1px solid var(--line);background:var(--card);color:var(--brand);text-decoration:none;transition:background .15s}
  .nav-btn:hover{background:#f0f9ff}
  .nav-btn-primary{background:#0ea5e9;color:#fff;border-color:#0ea5e9}
  .nav-btn-primary:hover{background:#0284c7;color:#fff}
  .nav-tip{font-size:11.5px;color:var(--sub);margin-left:6px}
  .weather-card{border-left:4px solid #f59e0b}
  .mets-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:14px}
  .met{background:linear-gradient(135deg,#f8fafc,#eef2f7);border:1px solid var(--line);border-radius:10px;padding:12px 14px;text-align:center;transition:transform .15s}
  .met:hover{transform:translateY(-1px);box-shadow:var(--shadow)}
  .met-icon{font-size:24px;margin-bottom:4px}
  .met-label{font-size:11.5px;color:var(--sub);font-weight:600;margin-bottom:2px}
  .met-val{font-size:17px;font-weight:800;color:var(--ink);line-height:1.2}
  .met-val .deg{font-size:11px;color:var(--sub);font-weight:500}
  .alerts-row{margin-top:14px;display:flex;flex-direction:column;gap:8px}
  .alert{padding:10px 14px;border-radius:8px;font-size:13px;line-height:1.6}
  .alert-high{background:#fef2f2;border:1px solid #fecaca;border-left:4px solid #dc2626;color:#991b1b}
  .alert-warn{background:#fffbeb;border:1px solid #fde68a;border-left:4px solid #f59e0b;color:#92400e}
  .alert-ok{background:#f0fdf4;border:1px solid #bbf7d0;border-left:4px solid #16a34a;color:#166534}
  .alert b{font-weight:800}
  .weather-forecast{width:100%;border-collapse:collapse;margin-top:12px;font-size:12.5px}
  .weather-forecast th{background:#f1f5f9;color:var(--ink);font-weight:700;padding:10px 8px;border-bottom:2px solid var(--line);text-align:left;font-size:12px}
  .weather-forecast td{padding:9px 8px;border-bottom:1px solid var(--line);color:var(--ink)}
  .weather-forecast tr.row-warn{background:#fff7ed}
  .weather-forecast tr.row-warn td:first-child{border-left:3px solid #f59e0b}
  .weather-forecast .deg{font-size:11px;color:var(--sub)}
  .legend{font-size:11.5px;color:var(--sub);margin-top:8px;text-align:center}
  .coord-src{font-size:11.5px;color:var(--sub);font-style:normal}
  .xcheck-card{border-left:4px solid #8b5cf6}
  .xcheck-card h3{color:#5b21b6}
  .xcheck-table th{background:#f5f3ff}
  .xcheck-table tr.row-warn td:first-child{border-left:3px solid #8b5cf6}
```

## 响应式补充

在已有的 `@media(max-width:860px)` 块里追加，避免手机上 4 列指标挤成一条：

```css
.mets-grid{grid-template-columns:repeat(2,1fr)}
.weather-forecast{font-size:11.5px}
```

## 大文件插入技巧

看板常内联 chart.js，文件可达 200KB+，直接用 Edit 匹配 `footer{...}` 可能不唯一。
用 Python 按锚点精确替换：

```python
ANCHOR = ".legend{font-size:11.5px;color:var(--sub);margin-top:8px;text-align:center}"
assert h.count(ANCHOR) == 1, f"锚点不唯一: {h.count(ANCHOR)}"
h = h.replace(ANCHOR, ANCHOR + NEW_CSS)
```

若目标 style 段难定位，先正则抽出所有 `<style>...</style>` 再在命中块内操作：

```python
for m in re.finditer(r'<style[^>]*>(.*?)</style>', h, re.S):
    if '.location-card' in m.group(1):
        ...
```
