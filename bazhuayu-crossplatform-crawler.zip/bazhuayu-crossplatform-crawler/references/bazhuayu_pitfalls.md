# 八爪鱼跨平台采集 · 踩坑清单（必读）

以下每条都是实战中真实踩过的坑。跳过任意一条都会浪费大量时间。

## 1. MCP 工具要先"断开重连"才加载

- 现象：调用 `mcp__bazhuayu__search_templates` 报 "not found" / "connector not found"。
- 原因：连接器此前未在当前会话加载。
- 解决：**让用户去设置里「断开再重连」八爪鱼连接器**，之后新会话工具才会就绪。
- 验证：重连后 `search_templates` 能返回真实模板列表即代表可用。

## 2. 快手 2893 任务成功但数据是空的（反爬）

- 现象：`execute_task` → `get_task_status` 显示 `completed`，但 `export_data` 返回的
  2 条（或 N 条）数据**标题/点赞/链接全为空字符串**。
- 原因：快手反爬拦截，云采集拿到空壳。
- 解决：**不要相信 completed 状态**。遇到空字段直接放弃该模板，改用 B站 2886 或 TikHub。

## 3. 签名 URL 只回 6 条预览

- 现象：`export_data` 返回的 `directAccess.curlTemplate` 是
  `https://mcp.bazhuayu.com/export?sign=...` 的 curl 命令。
- 坑：用这个签名 URL 去 `curl` / 下载，**只回 6 条预览数据**，不是整批（B站实际 80 条）。
- 解决：**完整数据只在 MCP `export_data` 的 in-context 返回里**。直接用工具返回的全部行，别去解签名 URL。

## 4. 国内直连八爪鱼官方 REST 不通

- 现象：`curl https://api.bazhuayu.com/api/v1/task/export`（带 Bearer / api_key）
  返回 `HTTP 000` / `Exit 28`（超时）。
- 解决：**彻底放弃官方 REST**，全程用八爪鱼 MCP 工具即可，MCP 已封装鉴权。

## 5. API KEY 不要入库

- 官方 KEY 形如 `op_sk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`。
- 若落盘为 `bazhuayu_config.json`，**必须加入 `.gitignore`**，禁止提交到任何仓库。
- 日常使用走 MCP/OAuth，KEY 仅作 REST 备用，本工作流基本用不到。

## 6. 人工筛选不可省

- 八爪鱼关键词搜索会混入大量话题漂移：纯路亚装备、纯做菜教程、魔方、手机评测等。
- 必须从原始结果（例 80 行）人工筛出与主题强相关的（例 16 条），再写 JSON。
- 筛选标准：标题/标签/简介含价格行情语义（价格/行情/多少钱/元/斤/统货/产值/降价/涨/卖鱼/养殖），且确为水产相关。

## 7. 锚点注入的幂等性

- 注入用正则 `START.*?END`（re.S 非贪婪）整段替换，**重复运行会覆盖上次注入结果**（幂等，不叠加）。
- 想还原：`python3 scripts/process_crossplatform.py --json 数据.json --html 看板.html --reset`。
- 注入前确认 HTML 中确实存在 `START` / `END` 两个锚点注释，否则脚本会中止并报错。
