---
name: farm-weather-monitor
description: 为任意固定地点（养殖场/工地/园区/光伏站）搭建「坐标定位 + 实时气象 + 多天预报 + 双源交叉校验 + 阈值告警 + 每日定时刷新」的完整监控模块，并注入已有 HTML 看板。当用户要求给某个地点加气象监测、天气看板、养殖/施工天气预警、每日定时天气刷新提醒，或提到气温/风速/风向/太阳辐射/降水量/相对湿度/气压 等 8 项指标时触发。已落地案例：江苏环荟·宜兴官林镇数字低碳生态养殖项目（鳜鱼/鲈鱼，已部署)。
---

# 地点气象监控看板（Farm Weather Monitor）

## Overview

给一个固定经纬度坐标搭一套可每日自动刷新的气象监控模块：位置卡（含导航） + 8 项实时指标 + 多天预报 + **双源交叉校验** + 阈值告警 + 定时 automation。

产出物是「注入已有 HTML 看板的锚点区块」，锚点幂等可重跑，不破坏看板其他区块。

## 核心决策：为什么是双源

| 数据源 | 提供字段 | 角色 | 需要 Key |
|---|---|---|---|
| **Open-Meteo** | 8 项全：气温℃、风速 km/h、风向°、太阳辐射 W/m²、降水量 mm、相对湿度%、气压 hPa、天气 code | **主源** | ❌ 免费无 Key |
| **高德天气** | 仅 4 天中文预报：白/夜天气、气温、风向、风力等级 | **校验源** | ✅ 需 Web服务 Key |

**关键约束**：高德天气 API **不提供**太阳辐射 / 降水量 mm / 相对湿度 / 气压。用户若要求完整 8 项，**主源必须是 Open-Meteo**，高德只能做校验，不能替代。

## Workflow

### Step 1 · 获取权威坐标

优先用高德地理编码（比 WebSearch 估读准）：

```
mcp__amap-maps__maps_geo(address="...", city="...")
→ location: "lng,lat"，记下 level（道路/POI/区县）
mcp__amap-maps__maps_regeocode(location="lng,lat")   # 反查校验行政区
```

同时用 `maps_text_search(keywords=项目名, city=...)` 交叉确认。
拿到 adcode（如宜兴市 `320282`），后续高德天气要用。

⚠️ 坐标必须标注来源（哪次地理编码、level 是什么），写进 `site.coord_source`，避免日后误改。

### Step 2 · 拉高德官方天气（校验源）

```
mcp__amap-maps__maps_weather(city="320282")
→ 写 amap_weather_latest.json，补 fetched_at_cst 字段
```

高德 MCP 常见问题：`USERKEY_PLAT_NOMATCH` = 连接器 Key 申请的接口类型与实际请求不匹配，**用户侧重新提交/授权 Key 才能解决**，代码层无法绕。若不可用：保留旧文件、降级单源、在汇报里说明。

### Step 3 · 跑 weather_fetcher.py（主源 + 校验）

改脚本顶部常量：`LAT` / `LON` / `ADDRESS` / `ADCODE` / `COORD_SOURCE`。
然后 `python3 weather_fetcher.py` → 输出 `farm_weather_latest.json`：

- `current`：8 项指标 + 天气中文（WMO code 映射）
- `daily`：7 天预报
- `amap`：高德原始 JSON
- `cross_check`：双源最高温比对，**偏差 ≥2°C 标 `mismatch`**
- `alerts`：阈值告警数组（`high` / `warn`）

### Step 4 · 注入看板

`python3 inject_weather_block.py`（幂等：先删旧 `WEATHER_LIVE_START/END` 区块再插到 `<footer` 之前）。

需要在看板 `<style>` 里预置样式，从 `references/dashboard_css.md` 复制（含 `.met` / `.weather-forecast` / `.mini-map` / `.nav-btn` / `.xcheck-*`）。

### Step 5 · 配置每日 automation

`automation_update` 建 recurring，流程顺序固定：

1. MCP 拉高德 → 写 `amap_weather_latest.json`（失败降级单源并说明）
2. `python3 weather_fetcher.py`
3. `python3 inject_weather_block.py` + git commit
4. 读告警并提醒：HIGH 必报（附处置建议）/ WARN 提醒 / **mismatch 单独提示** / 附 7 天预报概要

## 养殖业阈值（鳜鱼/鲈鱼，可按项目改）

| 指标 | 正常 | WARN | HIGH |
|---|---|---|---|
| 气温 | 28–30°C 最适 | 30–33°C | **≥33°C**（增氧/加深水位）|
| 风速 | ≤25 km/h | 25–38 | **≥38（6级）**（薄膜/光伏/围网）|
| 24h 降水 | ≤10mm | 10–25 / ≥25 | **≥50mm**（排水）|
| 气压 | ≥1005 hPa | **<1005**（风暴前兆）| — |
| 天气 code | — | — | **≥95 雷暴** |
| 太阳辐射 | — | >900 W/m² 关注水温 | — |

HIGH 告警必须给**处置建议**，不能只报数值。

## 踩坑清单

1. **高德天气缺 4 项字段**（辐射/降水mm/湿度/气压）→ 别指望单靠高德满足 8 项需求
2. **`USERKEY_PLAT_NOMATCH`** 是 Key 类型不匹配，需用户重新提交，非代码问题
3. **WMO code 会随时效变化**：Open-Meteo 15 分钟更新，雷暴 code 95 可能 15 分钟后变 51。跨时间对比告警数时要考虑时效，别误判成"坐标改错了"
4. **看板 HTML 可能内联 chart.js 导致 194KB+**：`grep` 会淹没在压缩 JS 里。要定位 style 段，用 Python 正则抽 `<style>...</style>` 再匹配，别直接 grep 全文件
5. **计数子串误判**：`blk.count("mini-map")` 会同时命中 `mini-map-link`，验证时用 `class="mini-map"` 精确串
6. **AMap JS API 嵌入真实地图**需单独的 **Web端(JS) Key**，与 MCP 用的 Web服务 Key 类型不同。没有 JS Key 时，**改用 Leaflet + 高德矢量 tile + CSS 反相**方案（零 Key、国内稳）：
   - Leaflet 1.9.4 框架（unpkg.com/leaflet@1.9.4，国内 750ms 能访问）
   - 底图：高德矢量 tile `https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}`（subdomains 1-4），公开、无 Key、国内 < 100ms
   - ⚠️ **CartoDB Dark Matter / OpenStreetMap tile 在国内被 GFW 墙**（HTTP 000），别用
   - ⚠️ **AMap JS API HTTP 层永远 200**，Key 校验在前端 JS 里 — 用 MCP Key 会**静默失败**，地图空白不易排查
   - CSS 反相：`filter: invert(1) hue-rotate(180deg) brightness(0.7) contrast(1.35) saturate(1.4)` 把白底矢量变深蓝科技感
   - 高德 tile 本身是 GCJ-02，marker 直接用 GCJ-02 坐标、Leaflet 不感知坐标系会忠实投影，无需 WGS84↔GCJ-02 转换
   - 点击地图 → e.latlng（WGS84）→ wgs84togcj02 转回 GCJ-02 → `https://uri.amap.com/navigation?from=lng,lat,起点&to=site_lng,site_lat,name&mode=car&coordinate=gaode&callnative=1`（无需 Key）
7. 地图类需求先加载 `geo-map-compliance-guard` skill
8. **inject 脚本最容易踩的坑**：定义 `<link>/<script src>` 字符串常量但当 f-string 字面拼接 → HTML 里只有文本而非真标签。**修复**：用 `inject_external_assets()` 一次性把 CDN 插入 `<head>` 和 `<body>` 顶部，配 `<!-- LEAFLET_CSS_HERE -->` 占位符防重复
9. **A_START/A_END 锚点范围**：要把整个 `<section>` 包裹（含 sec-head），否则重渲染时旧 sec-head 会残留导致"两个八、"重影

## Resources

- `scripts/weather_fetcher.py` — 抓 Open-Meteo + 合并高德 + 生成 cross_check/alerts
- `scripts/inject_weather_block.py` — 渲染区块 + **inject_external_assets() 注入 Leaflet CDN** + dark filter CSS + 幂等注入看板
- `references/dashboard_css.md` — 看板所需 CSS 片段（含 `.cn-tile-filter` 高德矢量反相样式）
- `references/api_fields.md` — 两源字段对照与 WMO code 表
