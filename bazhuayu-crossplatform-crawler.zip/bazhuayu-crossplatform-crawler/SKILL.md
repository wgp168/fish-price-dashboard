---
name: bazhuayu-crossplatform-crawler
description: 八爪鱼(Bazhuayu)云采集「跨平台社媒补充采集 → 人工筛选 → 注入 HTML 看板锚点」的可复用工作流。当用户已连接八爪鱼 MCP 连接器、需要补充抖音之外的平台（B站/快手/视频号）内容（如鳜鱼·鲈鱼价格讨论）到某个 HTML 看板时触发。覆盖模板选型、任务启停、导出陷阱、反爬空数据、锚点注入与回退。
agent_created: true
license: MIT
---

# 八爪鱼跨平台社媒补充采集（→ 筛选 → 注入看板）

## 用途

把八爪鱼云采集（Bazhuayu）当作"跨平台社媒采集器"，针对某个主题（例：鳜鱼/鲈鱼价格行情）
在 B站 / 快手 / 视频号 上做关键词搜索采集，人工筛掉无关内容后，把结果注入到
某个单文件 HTML 看板的「锚点区块」。抖音侧因八爪鱼无现成关键词搜索模板，改由 TikHub 覆盖。

## 何时使用

- 用户说"用八爪鱼补充采集""跨平台社媒补充""B站/快手/视频号采集""把社媒讨论注入看板"。
- 用户已连接八爪鱼 MCP 连接器，并希望把采集结果落到 HTML（含 `START/END` 注释锚点）。
- 需要补齐抖音之外平台的社媒声量/价格信号，与现有 TikHub 抖音数据形成双平台对照。

## 前置条件与重要约束

1. **八爪鱼 MCP 工具必须先加载**：连接器若此前未加载或报 "not found"，让用户先在
   设置里「断开再重连」八爪鱼连接器，新会话中工具才会可用
   （`mcp__bazhuayu__search_templates` 等 6 个工具）。
2. **API KEY 仅作 REST 备用**：官方 KEY（形如 `op_sk_...`）走 MCP/OAuth 已够用；
   若写进 `bazhuayu_config.json`，务必加入 `.gitignore`，禁止入库。
3. **国内直连八爪鱼官方 REST 不通**：`api.bazhuayu.com/api/v1/task/export` 带
   Bearer / api_key 均返回 HTTP 000（超时）。**只用 MCP 工具，不要折腾 REST。**

## 工作流（6 步）

### 第 1 步：确认模板可用性（先查后跑，避免空数据）

用 `search_templates` 按关键词（如「B站 搜索」「快手 搜索」「视频」）搜模板，
再 `search_tasks` 复核。实测可用/不可用结论见 `references/bazhuayu_templates.md`：

- **B站 `templateId=2886`（关键词搜索视频采集，Cloud，免费）→ ✅ 可用**，字段全（标题/UP主/播放/点赞/评论/发布时间/bvid）。
- **快手 `templateId=2893`（搜索关键词采集列表视频，免费）→ ❌ 不可用**：任务 completed，但导出字段全空（反爬拦截），丢弃。
- **抖音 / 视频号 → 八爪鱼无现成关键词搜索模板**，不在此连接器范围，交给 TikHub（抖音）。
- 快手若坚持要，改「个人账号视频采集」模板（需博主主页 URL + cookie），不在本工作流内。

### 第 2 步：启任务并轮询

- `execute_task`：以模板创建任务，传入关键词参数（如 `鳜鱼价格` / `鲈鱼价格`）。
- `get_task_status` 轮询至 `status == "completed"`（B站一次约 80 行结果，耗时几分钟）。

### 第 3 步：导出——用 MCP 工具，别用签名 URL

- 调 `export_data` 取回**完整结果**（in-context 直接拿到全部行）。
- ⚠️ 工具返回的 `directAccess.curlTemplate` 签名 URL
  （`https://mcp.bazhuayu.com/export?sign=...`）**只回 6 条预览**，不是整批。
  绝不能用它当完整数据源。

### 第 4 步：人工筛选（必做，无法自动化）

从原始结果（例：B站 80 行）人工筛出与主题强相关的视频，剔除无关话题：

- 保留：标题/标签/简介含价格行情语义（价格/行情/多少钱/元/斤/统货/产值/降价/涨/卖鱼/养殖）。
- 剔除：纯路亚装备、纯做菜教程、魔方、手机评测等话题漂移内容。
- 产出结构见 `references/data_schema.md`：一个 JSON，含 `meta`（platform/source/crawled_at/keywords/raw_rows/selected_rows/filter）
  与 `videos[]`（platform/keyword/title/author/play/like/comment/fav/date/bvid/url/tags）。

### 第 5 步：注入 HTML 锚点

用 `scripts/process_crossplatform.py` 把 JSON 渲染成表格并注入看板：

```bash
# 注入（默认锚点：<!-- CROSSPLATFORM_LIVE_START --> / <!-- CROSSPLATFORM_LIVE_END -->）
python3 scripts/process_crossplatform.py --json 数据.json --html 看板.html
# 还原为占位说明
python3 scripts/process_crossplatform.py --json 数据.json --html 看板.html --reset
# 自定义锚点
python3 scripts/process_crossplatform.py --json 数据.json --html 看板.html \
    --start "<!-- X_START -->" --end "<!-- X_END -->"
```

脚本用正则 `START.*?END`（re.S，非贪婪）替换锚点区间；表格中**含具体报价**
（元/斤/块/钱 等）的行自动高亮 `#fff7ed`，并抽取"价格信号" callout。

### 第 6 步：提交与归档

- 注入后提交代码；**密钥文件（bazhuayu_config.json）不要入库**（.gitignore 拦）。
- 如要推 GitHub，需仓库地址 + Token（用户侧提供），不要硬编码。

## 常见坑（速查）

详见 `references/bazhuayu_pitfalls.md`。最致命的三条：

1. 八爪鱼 MCP 工具要先"断开重连"才会加载。
2. 快手 2893 任务成功但数据是空的（反爬）——别信 completed 状态。
3. 签名 URL 只回 6 条预览；完整数据只在 MCP `export_data` 的 in-context 返回里。

## 安全

- API KEY / 配置文件：写入本地 `bazhuayu_config.json` 并加 `.gitignore`，禁止提交。
- 采集内容仅用于行情聚合展示，注意平台版权与 robots 约束。
