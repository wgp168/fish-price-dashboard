#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把八爪鱼采集 + 人工筛选后的跨平台社媒视频，注入 HTML 看板的锚点区块。

用法：
  # 注入（默认锚点）
  python3 process_crossplatform.py --json 数据.json --html 看板.html
  # 还原为占位说明
  python3 process_crossplatform.py --json 数据.json --html 看板.html --reset
  # 自定义锚点
  python3 process_crossplatform.py --json 数据.json --html 看板.html \
      --start "<!-- X_START -->" --end "<!-- X_END -->"

数据 JSON 结构（详见 references/data_schema.md）：
{
  "meta": {"platform","source","crawled_at","keywords":[],"raw_rows","selected_rows","filter"},
  "videos":[{"platform","keyword","title","author","play","like","comment",
             "fav","date","bvid","url","tags"}]
}
"""
import json, html, re, sys, os
import argparse

DEFAULT_START = "<!-- CROSSPLATFORM_LIVE_START -->"
DEFAULT_END = "<!-- CROSSPLATFORM_LIVE_END -->"

PLACEHOLDER = '''      <div class="card" style="margin-bottom:18px;border-left:4px solid #7c3aed;background:#faf5ff">
        <h3>📡 跨平台社媒补充（快手 / 视频号 / B站）— 待八爪鱼采集</h3>
        <div class="csub">本区块将补充抖音之外的平台相关讨论。待采集后注入。</div>
      </div>'''


def fmt(n):
    try:
        return f"{int(n):,}"
    except Exception:
        return str(n)


def build_html(data, start_anchor, end_anchor):
    meta = data.get("meta", {})
    videos = data.get("videos", [])
    crawled = meta.get("crawled_at", "")
    raw = meta.get("raw_rows", 0)
    sel = meta.get("selected_rows", len(videos))
    keywords = "、".join(meta.get("keywords", [])) or "（见 videos[].keyword）"

    rows = []
    price_signals = []
    for v in videos:
        kw = v.get("keyword", "")
        # 品种彩色 tag：含「鳜」归鳜鱼，否则归鲈鱼（可按需扩展）
        tag_cls = "tag-gui" if "鳜" in kw else "tag-lu"
        kw_label = "鳜鱼" if "鳜" in kw else "鲈鱼"
        title = v.get("title", "")
        url = v.get("url", "#")
        author = v.get("author", "")
        play = fmt(v.get("play", 0))
        like = fmt(v.get("like", 0))
        comment = fmt(v.get("comment", 0))
        date = v.get("date", "")
        # 含具体价格数字(元/斤/块/钱)的，高亮为行情信号
        hl = ""
        if re.search(r"(\d+(\.\d+)?\s*(元|块)|元/斤|/斤|\d+\s*块|\d+\s*元)", title):
            hl = ' style="background:#fff7ed"'
            price_signals.append(f"《{title}》— {author}（{date}）")
        rows.append(
            f'          <tr{hl}>\n'
            f'            <td><span class="tag {tag_cls}">{kw_label}</span></td>\n'
            f'            <td><a href="{html.escape(url)}" target="_blank" rel="noopener">{html.escape(title)}</a></td>\n'
            f'            <td>{html.escape(author)}</td>\n'
            f'            <td>{play}</td>\n'
            f'            <td>{like}</td>\n'
            f'            <td>{comment}</td>\n'
            f'            <td>{html.escape(date)}</td>\n'
            f'          </tr>'
        )
    rows_html = "\n".join(rows)

    signals_html = ""
    if price_signals:
        items = "\n".join(f"              <li>{html.escape(s)}</li>" for s in price_signals[:8])
        signals_html = (
            '      <div class="callout" style="margin-top:12px">\n'
            '        <b>💡 视频中透出的价格信号（含具体报价）：</b>\n'
            '        <ul style="margin:6px 0 0;padding-left:20px;line-height:1.9">\n'
            f'{items}\n'
            '        </ul>\n'
            '      </div>'
        )

    return f'''      <div class="card" style="margin-bottom:18px;border-left:4px solid #7c3aed;background:#faf5ff">
        <h3>📡 跨平台社媒补充（B站）— 相关主题视频</h3>
        <div class="csub">来源：八爪鱼云采集。采集时间 <b>{html.escape(crawled)}</b>；关键词「{html.escape(keywords)}」；原始 {raw} 条结果中筛出 <b>{sel} 条</b>与主题强相关。播放/点赞/评论为采集时点快照。</div>
        <table class="price-compare" style="margin-top:12px">
          <thead><tr><th>品种</th><th>视频标题</th><th>UP主</th><th>播放</th><th>点赞</th><th>评论</th><th>发布时间</th></tr></thead>
          <tbody>
{rows_html}
          </tbody>
        </table>{signals_html}
      </div>'''


def replace_region(html_text, start, end, frag):
    if start not in html_text or end not in html_text:
        raise SystemExit("未找到锚点（START/END），注入中止")
    pat = re.compile(re.escape(start) + r".*?" + re.escape(end), re.S)
    return pat.sub(start + "\n" + frag + "\n      " + end, html_text)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", required=True, help="筛选后的数据 JSON 路径")
    ap.add_argument("--html", required=True, help="目标 HTML 看板路径")
    ap.add_argument("--start", default=DEFAULT_START, help="起始锚点注释")
    ap.add_argument("--end", default=DEFAULT_END, help="结束锚点注释")
    ap.add_argument("--reset", action="store_true", help="还原为占位说明")
    args = ap.parse_args()

    with open(args.html, "r", encoding="utf-8") as f:
        html_text = f.read()

    if args.reset:
        new_text = replace_region(html_text, args.start, args.end, PLACEHOLDER)
        with open(args.html, "w", encoding="utf-8") as f:
            f.write(new_text)
        print("[ok] 已还原为占位说明")
        return

    with open(args.json, "r", encoding="utf-8") as f:
        data = json.load(f)
    frag = build_html(data, args.start, args.end)
    new_text = replace_region(html_text, args.start, args.end, frag)
    with open(args.html, "w", encoding="utf-8") as f:
        f.write(new_text)
    print(f"[ok] 已注入 {len(data.get('videos', []))} 条跨平台视频")


if __name__ == "__main__":
    main()
